package com.example.weatherapp;

public interface OnItemCitiesClick {
    void onItemCitiesClicked(String itemText);
}
